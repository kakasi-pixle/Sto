import { useEffect, useRef, useState, type ReactNode, type TransitionEvent } from "react";
import { ArrowUpRight } from "lucide-react";
import {
  SERVICE_IDS,
  SERVICES,
  WHATSAPP_DISPLAY,
  whatsappHref,
  type ShapeKind,
} from "@/lib/content";
import { useLocale } from "@/components/locale-provider";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const SHAPE_CLASS: Record<ShapeKind, string> = {
  square: "rounded-sm",
  circle: "rounded-full",
  diamond: "rotate-45 rounded-sm scale-75",
  hex: "rotate-12 rounded-md",
  rect: "rounded-sm scale-x-75",
  bars: "rounded-sm",
  octagon: "rounded-lg",
  ring: "rounded-full ring-1 ring-border",
};

function ShapeMark({
  shape,
  children,
  className,
}: {
  shape: ShapeKind;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "grid size-11 place-items-center border border-border text-foreground",
        SHAPE_CLASS[shape],
        className,
      )}
      aria-hidden="true"
    >
      <span className={cn("grid place-items-center", shape === "diamond" && "-rotate-45")}>
        {children}
      </span>
    </span>
  );
}

export function ServiceTicker() {
  const { t } = useLocale();
  const [offset, setOffset] = useState(0);
  const [stepping, setStepping] = useState(false);
  const steppingRef = useRef(false);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (media.matches) return;

    const tick = () => {
      if (document.visibilityState === "hidden") return;
      if (steppingRef.current) return;
      steppingRef.current = true;
      setStepping(true);
    };

    const id = window.setInterval(tick, 3200);
    return () => window.clearInterval(id);
  }, []);

  const handleTransitionEnd = (event: TransitionEvent<HTMLDivElement>) => {
    if (event.propertyName !== "transform") return;
    if (!stepping) return;
    setOffset((value) => (value + 1) % SERVICE_IDS.length);
    setStepping(false);
    steppingRef.current = false;
  };

  const windowIds = [0, 1, 2, 3].map(
    (slot) => SERVICE_IDS[(offset + slot) % SERVICE_IDS.length],
  );

  return (
    <section aria-label={t("tickerLabel")} className="w-full" dir="ltr">
      <p className="mb-5 text-xs font-medium tracking-[0.22em] text-subtle uppercase">
        {t("tickerLabel")}
      </p>
      <div className="overflow-hidden">
        <div
          className={cn("ticker-row", stepping && "ticker-step")}
          onTransitionEnd={handleTransitionEnd}
        >
          {windowIds.map((id, slot) => {
            const service = SERVICES[id];
            const Icon = service.icon;
            const incoming = slot === 3;
            const leaving = stepping && slot === 0;
            const faded = (incoming && !stepping) || leaving;
            return (
              <article
                key={`${id}-${offset}-${slot}`}
                className={cn(
                  "flex w-1/4 shrink-0 flex-col items-center gap-3 px-2 text-center transition-[opacity,filter] duration-700",
                  faded && "opacity-0 blur-[4px]",
                )}
              >
                <ShapeMark shape={service.shape}>
                  <Icon className="size-4" strokeWidth={1.6} />
                </ShapeMark>
                <p className="font-display text-sm leading-snug text-foreground sm:text-base sm:whitespace-nowrap">
                  {service.ticker}
                </p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function ServiceGrid() {
  const { locale, t } = useLocale();

  return (
    <section id="work" className="scroll-mt-24">
      <div className="max-w-xl">
        <h2 className="text-3xl text-foreground sm:text-4xl">{t("servicesTitle")}</h2>
        <p className="mt-3 text-muted">{t("servicesLead")}</p>
      </div>
      <ul className="mt-10 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {SERVICE_IDS.map((id) => {
          const service = SERVICES[id];
          const Icon = service.icon;
          const item = service[locale];
          return (
            <li key={id}>
              <article className="flex h-full gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)]">
                <ShapeMark shape={service.shape} className="shrink-0">
                  <Icon className="size-4" strokeWidth={1.6} />
                </ShapeMark>
                <div className="min-w-0">
                  <div className="flex items-baseline justify-between gap-3">
                    <h3 className="font-sans text-base font-medium tracking-tight text-foreground">
                      {item.name}
                    </h3>
                    <p className="shrink-0 text-xs tracking-wide text-subtle">{item.price}</p>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{item.blurb}</p>
                </div>
              </article>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function ContactBlock() {
  const { t } = useLocale();
  const href = whatsappHref(t("waGreeting"));

  return (
    <section id="contact" className="scroll-mt-24">
      <div className="rounded-2xl bg-card p-6 shadow-[var(--shadow-border)] sm:p-10">
        <p className="text-xs font-medium tracking-[0.22em] text-subtle uppercase">
          {t("phoneLabel")}
        </p>
        <h2 className="mt-3 text-3xl text-foreground sm:text-4xl">{t("contactTitle")}</h2>
        <p className="mt-3 max-w-lg text-muted">{t("contactLead")}</p>
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 block font-display text-3xl tracking-tight text-foreground sm:text-5xl"
          dir="ltr"
        >
          {WHATSAPP_DISPLAY}
        </a>
        <div className="mt-8">
          <Button asChild size="lg">
            <a href={href} target="_blank" rel="noopener noreferrer">
              {t("ctaWhatsapp")}
              <ArrowUpRight className="size-4" strokeWidth={1.75} />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
