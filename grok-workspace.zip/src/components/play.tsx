import { useEffect, useRef, useState } from "react";
import { CAT_MESSAGE_KEYS } from "@/lib/content";
import { useLocale } from "@/components/locale-provider";
import { cn } from "@/lib/utils";

const SHAPE_IDS = ["a", "b", "c", "d", "e", "f", "g"] as const;

function CatMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <path
        d="M14 30 L20 10 L28 24 H36 L44 10 L50 30 C52 48 42 56 32 56 S12 48 14 30Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinejoin="round"
      />
      <circle cx="26" cy="33" r="1.7" fill="currentColor" />
      <circle cx="38" cy="33" r="1.7" fill="currentColor" />
      <path
        d="M29 40 Q32 44 35 40"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function InteractiveShapes() {
  const [popped, setPopped] = useState<string | null>(null);
  const timer = useRef<number | null>(null);

  const pop = (id: string) => {
    setPopped(id);
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setPopped(null), 420);
  };

  useEffect(() => () => {
    if (timer.current) window.clearTimeout(timer.current);
  }, []);

  return (
    <div className="shape-stage">
      {SHAPE_IDS.map((id) => (
        <button
          key={id}
          type="button"
          className={cn("shape-hit", `shape-${id}`, popped === id && "is-pop")}
          aria-label="Shape"
          onClick={() => pop(id)}
        >
          <span className="shape-face" />
        </button>
      ))}
    </div>
  );
}

export function StudioCat() {
  const { t } = useLocale();
  const [line, setLine] = useState<string | null>(null);
  const last = useRef(-1);
  const hide = useRef<number | null>(null);

  const speak = () => {
    let next = Math.floor(Math.random() * CAT_MESSAGE_KEYS.length);
    if (next === last.current) next = (next + 1) % CAT_MESSAGE_KEYS.length;
    last.current = next;
    setLine(t(CAT_MESSAGE_KEYS[next]));
    if (hide.current) window.clearTimeout(hide.current);
    hide.current = window.setTimeout(() => setLine(null), 4200);
  };

  useEffect(() => () => {
    if (hide.current) window.clearTimeout(hide.current);
  }, []);

  return (
    <div className="relative">
      {line ? (
        <p className="cat-bubble" role="status">
          {line}
        </p>
      ) : null}
      <button type="button" className="cat-btn" onClick={speak} aria-label={t("catAria")}>
        <CatMark className="size-14" />
      </button>
    </div>
  );
}

export function CatGame() {
  const { t } = useLocale();
  const box = useRef<HTMLDivElement>(null);
  const [score, setScore] = useState(0);
  const [spot, setSpot] = useState({ x: 42, y: 38 });
  const [alive, setAlive] = useState(true);

  const place = () => {
    setSpot({
      x: 6 + Math.random() * 72,
      y: 22 + Math.random() * 52,
    });
    setAlive(true);
  };

  useEffect(() => {
    place();
  }, []);

  const catchCat = () => {
    if (!alive) return;
    setAlive(false);
    setScore((n) => n + 1);
    window.setTimeout(place, 280);
  };

  return (
    <div
      ref={box}
      className="relative mt-20 overflow-hidden rounded-2xl bg-card shadow-[var(--shadow-border)]"
    >
      <p className="absolute start-5 top-4 z-10 font-display text-sm tabular-nums text-foreground">
        {t("catsCaught")} {score}
      </p>
      <div className="relative h-72 sm:h-80">
        {alive ? (
          <button
            type="button"
            className="cat-btn cat-spawn absolute"
            style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
            aria-label={t("catAria")}
            onClick={catchCat}
          >
            <CatMark className="size-12" />
          </button>
        ) : null}
      </div>
    </div>
  );
}
