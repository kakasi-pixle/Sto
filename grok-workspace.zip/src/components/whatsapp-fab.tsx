import { MessageCircle } from "lucide-react";
import { whatsappHref } from "@/lib/content";
import { useLocale } from "@/components/locale-provider";

export function WhatsappFab() {
  const { t } = useLocale();
  return (
    <a
      href={whatsappHref(t("waGreeting"))}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={t("ctaWhatsapp")}
      className="fixed end-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-40 grid size-12 place-items-center rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-border)] transition-[transform,opacity] duration-150 ease-out hover:opacity-90 active:scale-[0.96] sm:end-6"
    >
      <MessageCircle className="size-5" strokeWidth={1.75} />
    </a>
  );
}
