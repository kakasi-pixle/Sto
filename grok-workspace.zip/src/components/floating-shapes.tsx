export function FloatingShapes() {
  return (
    <div className="shape-stage" aria-hidden="true">
      <span className="shape-mark shape-a" />
      <span className="shape-mark shape-b" />
      <span className="shape-mark shape-c" />
      <span className="shape-mark shape-d" />
      <span className="shape-mark shape-e" />
      <span className="shape-mark shape-f" />
      <span className="shape-mark shape-g" />
    </div>
  );
}
