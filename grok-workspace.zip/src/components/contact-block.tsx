import { ArrowUpRight } from "lucide-react";
import { WHATSAPP_DISPLAY, whatsappHref } from "@/lib/content";
import { useLocale } from "@/components/locale-provider";
import { Button } from "@/components/ui/button";

export function ContactBlock() {
  const { t } = useLocale();
  const href = whatsappHref(t("waGreeting"));

  return (
    <section id="contact" className="scroll-mt-24">
      <div className="rounded-2xl bg-card p-6 shadow-[var(--shadow-border)] sm:p-10">
        <p className="text-xs font-medium tracking-[0.22em] text-subtle uppercase">
          {t("phoneLabel")}
        </p>
        <h2 className="mt-3 text-3xl text-foreground sm:text-4xl">{t("contactTitle")}</h2>
        <p className="mt-3 max-w-lg text-muted">{t("contactLead")}</p>
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 block font-display text-3xl tracking-tight text-foreground sm:text-5xl"
          dir="ltr"
        >
          {WHATSAPP_DISPLAY}
        </a>
        <div className="mt-8">
          <Button asChild size="lg">
            <a href={href} target="_blank" rel="noopener noreferrer">
              {t("ctaWhatsapp")}
              <ArrowUpRight className="size-4" strokeWidth={1.75} />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
