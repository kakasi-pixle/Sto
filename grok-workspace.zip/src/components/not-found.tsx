import { Link } from "@tanstack/react-router";
import { useLocale } from "@/components/locale-provider";
import { Button } from "@/components/ui/button";

export function NotFoundPage() {
  const { t } = useLocale();

  return (
    <div className="mx-auto flex min-h-[60dvh] max-w-5xl flex-col justify-center px-4 py-20 sm:px-6">
      <h1 className="text-4xl text-foreground">{t("notFoundTitle")}</h1>
      <p className="mt-4 max-w-md text-muted">{t("notFoundBody")}</p>
      <div className="mt-8">
        <Button asChild>
          <Link to="/">{t("notFoundHome")}</Link>
        </Button>
      </div>
    </div>
  );
}
