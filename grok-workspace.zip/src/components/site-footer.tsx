import { Link } from "@tanstack/react-router";
import { WHATSAPP_DISPLAY, whatsappHref } from "@/lib/content";
import { useLocale } from "@/components/locale-provider";

export function SiteFooter() {
  const { t } = useLocale();

  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-5xl flex-col gap-4 px-4 py-8 pb-24 sm:flex-row sm:items-center sm:justify-between sm:px-6 sm:pb-10">
        <p className="text-sm text-muted">{t("footerMade")}</p>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
          <Link to="/about" className="text-muted transition-colors duration-150 hover:text-foreground">
            {t("navAbout")}
          </Link>
          <a
            href={whatsappHref(t("waGreeting"))}
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted transition-colors duration-150 hover:text-foreground"
          >
            {WHATSAPP_DISPLAY}
          </a>
        </div>
      </div>
    </footer>
  );
}
