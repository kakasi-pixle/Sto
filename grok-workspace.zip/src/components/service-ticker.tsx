import { useEffect, useRef, useState, type TransitionEvent } from "react";
import { SERVICE_IDS, SERVICES } from "@/lib/content";
import { useLocale } from "@/components/locale-provider";
import { ShapeMark } from "@/components/shape-mark";
import { cn } from "@/lib/utils";

const VISIBLE = 3;

export function ServiceTicker() {
  const { t } = useLocale();
  const [offset, setOffset] = useState(0);
  const [stepping, setStepping] = useState(false);
  const steppingRef = useRef(false);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (media.matches) return;

    const tick = () => {
      if (document.visibilityState === "hidden") return;
      if (steppingRef.current) return;
      steppingRef.current = true;
      setStepping(true);
    };

    const id = window.setInterval(tick, 3200);
    return () => window.clearInterval(id);
  }, []);

  const handleTransitionEnd = (event: TransitionEvent<HTMLDivElement>) => {
    if (event.propertyName !== "transform") return;
    if (!stepping) return;
    setOffset((value) => (value + 1) % SERVICE_IDS.length);
    setStepping(false);
    steppingRef.current = false;
  };

  const windowIds = [0, 1, 2, 3].map(
    (slot) => SERVICE_IDS[(offset + slot) % SERVICE_IDS.length],
  );

  return (
    <section aria-label={t("tickerLabel")} className="w-full" dir="ltr">
      <p className="mb-5 text-xs font-medium tracking-[0.22em] text-subtle uppercase">
        {t("tickerLabel")}
      </p>
      <div className="overflow-hidden">
        <div
          className={cn("ticker-row", stepping && "ticker-step")}
          onTransitionEnd={handleTransitionEnd}
        >
          {windowIds.map((id, slot) => {
            const service = SERVICES[id];
            const Icon = service.icon;
            const incoming = slot === VISIBLE;
            const leaving = stepping && slot === 0;
            const faded = (incoming && !stepping) || leaving;
            return (
              <article
                key={`${id}-${offset}-${slot}`}
                className={cn(
                  "flex w-1/4 shrink-0 flex-col items-center gap-3 px-2 text-center transition-[opacity,filter] duration-700",
                  faded && "opacity-0 blur-[4px]",
                )}
              >
                <ShapeMark shape={service.shape}>
                  <Icon className="size-4" strokeWidth={1.6} />
                </ShapeMark>
                <p className="font-display text-sm leading-snug text-foreground sm:text-base sm:whitespace-nowrap">
                  {service.ticker}
                </p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
