import { cn } from "@/lib/utils";
import type { ShapeKind } from "@/lib/content";
import type { ReactNode } from "react";

const shapeClass: Record<ShapeKind, string> = {
  square: "rounded-sm",
  circle: "rounded-full",
  diamond: "rotate-45 rounded-sm scale-75",
  hex: "rotate-12 rounded-md",
  rect: "rounded-sm scale-x-75",
  bars: "rounded-sm",
  octagon: "rounded-lg",
  ring: "rounded-full ring-1 ring-border",
};

export function ShapeMark({
  shape,
  children,
  className,
}: {
  shape: ShapeKind;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "grid size-11 place-items-center border border-border text-foreground",
        shapeClass[shape],
        className,
      )}
      aria-hidden="true"
    >
      <span className={cn("grid place-items-center", shape === "diamond" && "-rotate-45")}>
        {children}
      </span>
    </span>
  );
}
