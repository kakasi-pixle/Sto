import { Link } from "@tanstack/react-router";
import { useLocale } from "@/components/locale-provider";
import { Button } from "@/components/ui/button";

export function SiteHeader() {
  const { t, toggle } = useLocale();

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur-sm">
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link
          to="/"
          className="text-xs font-medium tracking-[0.22em] text-foreground uppercase"
        >
          {t("brand")}
        </Link>
        <nav className="flex items-center gap-1 sm:gap-2">
          <a
            href="/#work"
            className="inline-flex h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground"
          >
            {t("navWork")}
          </a>
          <Link
            to="/about"
            className="inline-flex h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground"
          >
            {t("navAbout")}
          </Link>
          <a
            href="/#contact"
            className="hidden h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground sm:inline-flex"
          >
            {t("navContact")}
          </a>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={toggle}
            aria-label={t("langAria")}
            className="ms-1 min-w-11 tracking-wide"
          >
            {t("langShort")}
          </Button>
        </nav>
      </div>
    </header>
  );
}
