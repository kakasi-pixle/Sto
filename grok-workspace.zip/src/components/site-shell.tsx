import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import { WHATSAPP_DISPLAY, whatsappHref } from "@/lib/content";
import { useLocale } from "@/components/locale-provider";
import { Button } from "@/components/ui/button";

export function SiteShell({ children }: { children: ReactNode }) {
  const { t, toggle } = useLocale();
  const wa = whatsappHref(t("waGreeting"));

  return (
    <div className="relative flex min-h-dvh flex-col bg-background text-foreground">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground"
      >
        {t("skip")}
      </a>
      <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur-sm">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <Link to="/" className="font-display text-base tracking-tight text-foreground">
            {t("brand")}
          </Link>
          <nav className="flex items-center gap-1 sm:gap-2">
            <a
              href="/#work"
              className="inline-flex h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground"
            >
              {t("navWork")}
            </a>
            <Link
              to="/about"
              className="inline-flex h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground"
            >
              {t("navAbout")}
            </Link>
            <a
              href="/#contact"
              className="hidden h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground sm:inline-flex"
            >
              {t("navContact")}
            </a>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={toggle}
              aria-label={t("langAria")}
              className="ms-1 min-w-11 tracking-wide"
            >
              {t("langShort")}
            </Button>
          </nav>
        </div>
      </header>
      <main id="main" className="flex-1">
        {children}
      </main>
      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-5xl flex-col gap-4 px-4 py-8 pb-24 sm:flex-row sm:items-center sm:justify-between sm:px-6 sm:pb-10">
          <p className="font-display text-sm text-muted">{t("footerMade")}</p>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
            <Link to="/about" className="text-muted transition-colors duration-150 hover:text-foreground">
              {t("navAbout")}
            </Link>
            <a
              href={wa}
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted transition-colors duration-150 hover:text-foreground"
            >
              {WHATSAPP_DISPLAY}
            </a>
          </div>
        </div>
      </footer>
      <a
        href={wa}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={t("ctaWhatsapp")}
        className="fixed end-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-40 grid size-12 place-items-center rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-border)] transition-[transform,opacity] duration-150 ease-out hover:opacity-90 active:scale-[0.96] sm:end-6"
      >
        <MessageCircle className="size-5" strokeWidth={1.75} />
      </a>
    </div>
  );
}
