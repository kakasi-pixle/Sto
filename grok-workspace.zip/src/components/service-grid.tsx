import { SERVICE_IDS, SERVICES } from "@/lib/content";
import { useLocale } from "@/components/locale-provider";
import { ShapeMark } from "@/components/shape-mark";

export function ServiceGrid() {
  const { locale, t } = useLocale();

  return (
    <section id="work" className="scroll-mt-24">
      <div className="max-w-xl">
        <h2 className="text-3xl text-foreground sm:text-4xl">{t("servicesTitle")}</h2>
        <p className="mt-3 text-muted">{t("servicesLead")}</p>
      </div>
      <ul className="mt-10 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {SERVICE_IDS.map((id) => {
          const service = SERVICES[id];
          const Icon = service.icon;
          const copy = service[locale];
          return (
            <li key={id}>
              <article className="flex h-full gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)]">
                <ShapeMark shape={service.shape} className="shrink-0">
                  <Icon className="size-4" strokeWidth={1.6} />
                </ShapeMark>
                <div className="min-w-0">
                  <div className="flex items-baseline justify-between gap-3">
                    <h3 className="font-sans text-base font-medium tracking-tight text-foreground">
                      {copy.name}
                    </h3>
                    <p className="shrink-0 text-xs tracking-wide text-subtle">{copy.price}</p>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{copy.blurb}</p>
                </div>
              </article>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
