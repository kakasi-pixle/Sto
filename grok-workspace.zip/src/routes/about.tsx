import { createFileRoute } from "@tanstack/react-router";
import { useLocale } from "@/components/locale-provider";
import { VERSE_LINES } from "@/lib/content";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  const { t } = useLocale();

  return (
    <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-24">
      <p className="enter-1 text-xs font-medium tracking-[0.22em] text-subtle uppercase">
        {t("aboutOverline")}
      </p>
      <h1 className="enter-2 mt-4 max-w-2xl text-4xl leading-[1.1] text-foreground sm:text-5xl">
        {t("aboutTitle")}
      </h1>
      <p className="enter-3 mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
        {t("aboutBody")}
      </p>

      <figure className="enter-4 mx-auto mt-20 max-w-2xl rounded-2xl bg-card px-6 py-12 text-center shadow-[var(--shadow-border)] sm:px-12 sm:py-16">
        <figcaption className="text-xs font-medium tracking-[0.22em] text-subtle uppercase">
          {t("verseLabel")}
        </figcaption>
        <blockquote
          lang="ar"
          dir="rtl"
          className="font-verse mt-8 text-2xl leading-[2.05] text-foreground sm:text-3xl"
        >
          {VERSE_LINES.map((line, index) => (
            <span key={line} className="block">
              {index === 0 ? <span className="text-muted">﴿</span> : null}
              {line}
              {index === VERSE_LINES.length - 1 ? (
                <span className="text-muted">﴾</span>
              ) : null}
            </span>
          ))}
        </blockquote>
        <p className="mx-auto mt-8 max-w-md text-sm leading-relaxed text-muted">
          {t("verseTranslation")}
        </p>
      </figure>

      <p className="mt-16 text-sm text-muted">{t("aboutCredit")}</p>
    </div>
  );
}
