import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { FloatingShapes } from "@/components/floating-shapes";
import { ServiceTicker } from "@/components/service-ticker";
import { ServiceGrid } from "@/components/service-grid";
import { ContactBlock } from "@/components/contact-block";
import { Button } from "@/components/ui/button";
import { useLocale } from "@/components/locale-provider";
import { whatsappHref } from "@/lib/content";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { t } = useLocale();
  const href = whatsappHref(t("waGreeting"));

  return (
    <div>
      <section className="relative overflow-hidden">
        <FloatingShapes />
        <div className="relative mx-auto flex min-h-[calc(100dvh-3.5rem)] max-w-5xl flex-col justify-center gap-12 px-4 py-16 sm:px-6 sm:py-20">
          <div className="max-w-2xl">
            <p className="enter-1 text-xs font-medium tracking-[0.22em] text-subtle uppercase">
              {t("overline")}
            </p>
            <h1 className="enter-2 mt-4 text-4xl leading-[1.08] text-foreground sm:text-6xl">
              {t("heroTitle")}
              <span className="mt-1 block">{t("heroTitleLine")}</span>
            </h1>
            <p className="enter-3 mt-5 max-w-lg text-base leading-relaxed text-muted sm:text-lg">
              {t("heroLead")}
            </p>
            <div className="enter-4 mt-8 flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg">
                <a href={href} target="_blank" rel="noopener noreferrer">
                  {t("ctaWhatsapp")}
                  <ArrowUpRight className="size-4" strokeWidth={1.75} />
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="#work">{t("ctaWork")}</a>
              </Button>
            </div>
          </div>
          <div className="enter-4">
            <ServiceTicker />
          </div>
        </div>
      </section>
      <div className="mx-auto flex max-w-5xl flex-col gap-24 px-4 py-16 sm:px-6 sm:py-24">
        <ServiceGrid />
        <ContactBlock />
      </div>
    </div>
  );
}
