import {
  Code2,
  Cpu,
  FileCode2,
  Globe,
  Link2,
  MessageCircle,
  Send,
  Server,
  type LucideIcon,
} from "lucide-react";

export const WHATSAPP_E164 = "201550680822";
export const WHATSAPP_DISPLAY = "01550680822";

export function whatsappHref(text?: string) {
  const url = new URL(`https://wa.me/${WHATSAPP_E164}`);
  if (text) url.searchParams.set("text", text);
  return url.toString();
}

export type Locale = "en" | "ar";
export type ShapeKind =
  | "square"
  | "circle"
  | "diamond"
  | "hex"
  | "rect"
  | "bars"
  | "octagon"
  | "ring";

export type ServiceId =
  | "whatsapp"
  | "telegram"
  | "websites"
  | "scripts"
  | "codes"
  | "servers"
  | "vps"
  | "domains";

export const SERVICE_IDS: ServiceId[] = [
  "whatsapp",
  "telegram",
  "websites",
  "scripts",
  "codes",
  "servers",
  "vps",
  "domains",
];

export type ServiceCopy = {
  name: string;
  blurb: string;
  price: string;
};

export const SERVICES: Record<
  ServiceId,
  {
    id: ServiceId;
    ticker: string;
    icon: LucideIcon;
    shape: ShapeKind;
    en: ServiceCopy;
    ar: ServiceCopy;
  }
> = {
  whatsapp: {
    id: "whatsapp",
    ticker: "WhatsApp Bot",
    icon: MessageCircle,
    shape: "square",
    en: {
      name: "WhatsApp Bot",
      blurb: "Orders, alerts, and support that live inside WhatsApp.",
      price: "EGP 50–500",
    },
    ar: {
      name: "WhatsApp Bot",
      blurb: "طلبات وتنبيهات ودعم داخل واتساب.",
      price: "٥٠–٥٠٠ جنيه",
    },
  },
  telegram: {
    id: "telegram",
    ticker: "Telegram Bot",
    icon: Send,
    shape: "circle",
    en: {
      name: "Telegram Bot",
      blurb: "Custom bots for groups, shops, and operations.",
      price: "On request",
    },
    ar: {
      name: "Telegram Bot",
      blurb: "بوتات مخصّصة للمجموعات والمتاجر والتشغيل.",
      price: "حسب الاتفاق",
    },
  },
  websites: {
    id: "websites",
    ticker: "Websites",
    icon: Globe,
    shape: "diamond",
    en: {
      name: "Websites",
      blurb: "Landing pages and full sites, built to the brief.",
      price: "By brief",
    },
    ar: {
      name: "Websites",
      blurb: "صفحات هبوط ومواقع كاملة حسب الوصف.",
      price: "حسب الوصف",
    },
  },
  scripts: {
    id: "scripts",
    ticker: "Scripts",
    icon: FileCode2,
    shape: "hex",
    en: {
      name: "Scripts",
      blurb: "Automation and tools that cut the repetitive hours.",
      price: "By brief",
    },
    ar: {
      name: "Scripts",
      blurb: "أتمتة وأدوات تختصر الساعات المتكررة.",
      price: "حسب الوصف",
    },
  },
  codes: {
    id: "codes",
    ticker: "Codes",
    icon: Code2,
    shape: "rect",
    en: {
      name: "Codes",
      blurb: "Focused code, APIs, and small systems.",
      price: "By brief",
    },
    ar: {
      name: "Codes",
      blurb: "كود مركّز وواجهات برمجية وأنظمة صغيرة.",
      price: "حسب الوصف",
    },
  },
  servers: {
    id: "servers",
    ticker: "Servers",
    icon: Server,
    shape: "bars",
    en: {
      name: "Servers",
      blurb: "Setup, hardening, and ongoing care.",
      price: "By brief",
    },
    ar: {
      name: "Servers",
      blurb: "إعداد وتأمين ورعاية مستمرة.",
      price: "حسب الوصف",
    },
  },
  vps: {
    id: "vps",
    ticker: "VPS",
    icon: Cpu,
    shape: "octagon",
    en: {
      name: "VPS",
      blurb: "Specced to the workload. Details on WhatsApp.",
      price: "By details",
    },
    ar: {
      name: "VPS",
      blurb: "حسب التفاصيل وحجم العمل. تواصل واتساب.",
      price: "حسب التفاصيل",
    },
  },
  domains: {
    id: "domains",
    ticker: "Domains",
    icon: Link2,
    shape: "ring",
    en: {
      name: "Domains",
      blurb: "Registration, DNS, and transfer help.",
      price: "By brief",
    },
    ar: {
      name: "Domains",
      blurb: "تسجيل ونقل وإعداد أسماء النطاق.",
      price: "حسب الوصف",
    },
  },
};

export const VERSE_LINES = [
  "فَإِذَا قُضِيَتِ الصَّلَاةُ",
  "فَانتَشِرُوا فِي الْأَرْضِ",
  "وَابْتَغُوا مِن فَضْلِ اللَّهِ",
] as const;

export const CAT_MESSAGE_KEYS = ["catSale", "catCustom", "catRights"] as const;

export const copy = {
  en: {
    brand: "Shawarma",
    navWork: "Work",
    navAbout: "About",
    navContact: "Contact",
    langShort: "AR",
    langAria: "Switch to Arabic",
    overline: "Digital studio",
    heroTitle: "Quiet systems.",
    heroTitleLine: "Precise work.",
    heroLead:
      "Bots, sites, scripts, and servers — scoped to the brief, priced with care.",
    ctaWhatsapp: "WhatsApp",
    ctaWork: "See services",
    tickerLabel: "Now building",
    servicesTitle: "What we make",
    servicesLead: "Ranges are starting points. The brief sets the rest.",
    contactTitle: "Talk on WhatsApp",
    contactLead: "One number. Direct chat. No forms, no accounts.",
    phoneLabel: "WhatsApp",
    footerMade: "Shawarma",
    aboutOverline: "The practice",
    aboutTitle: "A small studio for digital work.",
    verseLabel: "Al-Jumuʿah 62:10",
    verseTranslation:
      "When the prayer is concluded, disperse in the land and seek from the bounty of Allah.",
    notFoundTitle: "Page missing",
    notFoundBody: "That path is not part of the studio.",
    notFoundHome: "Back home",
    waGreeting: "Hello Shawarma — I would like to talk about a project.",
    skip: "Skip to work",
    catSale: "There are discounts on.",
    catCustom: "Need something new? Ask — it can be built for you.",
    catRights: "You keep full rights. None stay with the developer.",
    catAria: "Cat",
    catsCaught: "Cats",
  },
  ar: {
    brand: "Shawarma",
    navWork: "الأعمال",
    navAbout: "تعريف",
    navContact: "تواصل",
    langShort: "EN",
    langAria: "التبديل إلى الإنجليزية",
    overline: "استوديو رقمي",
    heroTitle: "أنظمة هادئة.",
    heroTitleLine: "عمل دقيق.",
    heroLead: "بوتات ومواقع وسكربتات وسيرفرات — حسب الوصف، بأسعار واضحة.",
    ctaWhatsapp: "واتساب",
    ctaWork: "الخدمات",
    tickerLabel: "نعمل الآن",
    servicesTitle: "ماذا نصنع",
    servicesLead: "الأسعار نقطة بداية. التفاصيل من الوصف.",
    contactTitle: "تواصل واتساب",
    contactLead: "رقم واحد. محادثة مباشرة. بلا نماذج وبلا حسابات.",
    phoneLabel: "واتساب",
    footerMade: "Shawarma",
    aboutOverline: "الممارسة",
    aboutTitle: "استوديو صغير للعمل الرقمي.",
    verseLabel: "الجمعة ١٠",
    verseTranslation:
      "فإذا قُضيت الصلاة فانتشروا في الأرض وابتغوا من فضل الله.",
    notFoundTitle: "الصفحة غير موجودة",
    notFoundBody: "هذا المسار ليس جزءاً من الاستوديو.",
    notFoundHome: "العودة للرئيسية",
    waGreeting: "مرحباً Shawarma — أود الحديث عن مشروع.",
    skip: "إلى الأعمال",
    catSale: "في تخفيضات.",
    catCustom: "تقدر تخصّص حاجة جديدة والمطوّر يعملها لك.",
    catRights: "كل حاجة بحقوقك كاملة، من غير أي حقوق للمطوّر.",
    catAria: "قطة",
    catsCaught: "قطط",
  },
} as const;

export type CopyKey = keyof typeof copy.en;
