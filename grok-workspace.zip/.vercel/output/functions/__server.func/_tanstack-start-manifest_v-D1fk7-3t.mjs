//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D1fk7-3t.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/about"],
		preloads: ["/assets/index-COuaEY9a.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-COuaEY9a.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-De3bkiZ4.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CXHoCmUv.js"]
	}
} });
//#endregion
export { tsrStartManifest };
