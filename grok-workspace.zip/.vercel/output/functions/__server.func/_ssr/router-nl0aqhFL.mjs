import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createFileRoute, b as useRouter, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Link2, c as Cpu, i as MessageCircle, l as CodeXml, n as Server, o as Globe, r as Send, s as FileCode2, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-nl0aqhFL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 1.75
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-lg font-medium",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var WHATSAPP_E164 = "201550680822";
var WHATSAPP_DISPLAY = "01550680822";
function whatsappHref(text) {
	const url = new URL(`https://wa.me/${WHATSAPP_E164}`);
	if (text) url.searchParams.set("text", text);
	return url.toString();
}
var SERVICE_IDS = [
	"whatsapp",
	"telegram",
	"websites",
	"scripts",
	"codes",
	"servers",
	"vps",
	"domains"
];
var SERVICES = {
	whatsapp: {
		id: "whatsapp",
		ticker: "WhatsApp Bot",
		icon: MessageCircle,
		shape: "square",
		en: {
			name: "WhatsApp Bot",
			blurb: "Orders, alerts, and support that live inside WhatsApp.",
			price: "EGP 50–500"
		},
		ar: {
			name: "WhatsApp Bot",
			blurb: "طلبات وتنبيهات ودعم داخل واتساب.",
			price: "٥٠–٥٠٠ جنيه"
		}
	},
	telegram: {
		id: "telegram",
		ticker: "Telegram Bot",
		icon: Send,
		shape: "circle",
		en: {
			name: "Telegram Bot",
			blurb: "Custom bots for groups, shops, and operations.",
			price: "On request"
		},
		ar: {
			name: "Telegram Bot",
			blurb: "بوتات مخصّصة للمجموعات والمتاجر والتشغيل.",
			price: "حسب الاتفاق"
		}
	},
	websites: {
		id: "websites",
		ticker: "Websites",
		icon: Globe,
		shape: "diamond",
		en: {
			name: "Websites",
			blurb: "Landing pages and full sites, built to the brief.",
			price: "By brief"
		},
		ar: {
			name: "Websites",
			blurb: "صفحات هبوط ومواقع كاملة حسب الوصف.",
			price: "حسب الوصف"
		}
	},
	scripts: {
		id: "scripts",
		ticker: "Scripts",
		icon: FileCode2,
		shape: "hex",
		en: {
			name: "Scripts",
			blurb: "Automation and tools that cut the repetitive hours.",
			price: "By brief"
		},
		ar: {
			name: "Scripts",
			blurb: "أتمتة وأدوات تختصر الساعات المتكررة.",
			price: "حسب الوصف"
		}
	},
	codes: {
		id: "codes",
		ticker: "Codes",
		icon: CodeXml,
		shape: "rect",
		en: {
			name: "Codes",
			blurb: "Focused code, APIs, and small systems.",
			price: "By brief"
		},
		ar: {
			name: "Codes",
			blurb: "كود مركّز وواجهات برمجية وأنظمة صغيرة.",
			price: "حسب الوصف"
		}
	},
	servers: {
		id: "servers",
		ticker: "Servers",
		icon: Server,
		shape: "bars",
		en: {
			name: "Servers",
			blurb: "Setup, hardening, and ongoing care.",
			price: "By brief"
		},
		ar: {
			name: "Servers",
			blurb: "إعداد وتأمين ورعاية مستمرة.",
			price: "حسب الوصف"
		}
	},
	vps: {
		id: "vps",
		ticker: "VPS",
		icon: Cpu,
		shape: "octagon",
		en: {
			name: "VPS",
			blurb: "Specced to the workload. Details on WhatsApp.",
			price: "By details"
		},
		ar: {
			name: "VPS",
			blurb: "حسب التفاصيل وحجم العمل. تواصل واتساب.",
			price: "حسب التفاصيل"
		}
	},
	domains: {
		id: "domains",
		ticker: "Domains",
		icon: Link2,
		shape: "ring",
		en: {
			name: "Domains",
			blurb: "Registration, DNS, and transfer help.",
			price: "By brief"
		},
		ar: {
			name: "Domains",
			blurb: "تسجيل ونقل وإعداد أسماء النطاق.",
			price: "حسب الوصف"
		}
	}
};
var VERSE_LINES = [
	"فَإِذَا قُضِيَتِ الصَّلَاةُ",
	"فَانتَشِرُوا فِي الْأَرْضِ",
	"وَابْتَغُوا مِن فَضْلِ اللَّهِ"
];
var copy = {
	en: {
		brand: "Shawarma 2023",
		navWork: "Work",
		navAbout: "About",
		navContact: "Contact",
		langShort: "AR",
		langAria: "Switch to Arabic",
		overline: "Digital studio",
		heroTitle: "Quiet systems.",
		heroTitleLine: "Precise work.",
		heroLead: "Bots, sites, scripts, and servers — scoped to the brief, priced with care.",
		ctaWhatsapp: "WhatsApp",
		ctaWork: "See services",
		tickerLabel: "Now building",
		servicesTitle: "What we make",
		servicesLead: "Ranges are starting points. The brief sets the rest.",
		contactTitle: "Talk on WhatsApp",
		contactLead: "One number. Direct chat. No forms, no accounts.",
		phoneLabel: "WhatsApp",
		footerMade: "Made by Shawarma 2023",
		aboutNav: "About",
		aboutOverline: "The practice",
		aboutTitle: "A small studio for digital work.",
		aboutBody: "Shawarma 2023 builds bots, websites, scripts, and infrastructure without noise. No sign-up on this site. If the brief is clear, we start. If it is not, we talk until it is.",
		verseLabel: "Al-Jumuʿah 62:10",
		verseText: "فَإِذَا قُضِيَتِ الصَّلَاةُ فَانتَشِرُوا فِي الْأَرْضِ وَابْتَغُوا مِن فَضْلِ اللَّهِ",
		verseTranslation: "When the prayer is concluded, disperse in the land and seek from the bounty of Allah.",
		aboutCredit: "This site is made by Shawarma 2023.",
		notFoundTitle: "Page missing",
		notFoundBody: "That path is not part of the studio.",
		notFoundHome: "Back home",
		waGreeting: "Hello Shawarma 2023 — I would like to talk about a project.",
		skip: "Skip to work"
	},
	ar: {
		brand: "Shawarma 2023",
		navWork: "الأعمال",
		navAbout: "تعريف",
		navContact: "تواصل",
		langShort: "EN",
		langAria: "التبديل إلى الإنجليزية",
		overline: "استوديو رقمي",
		heroTitle: "أنظمة هادئة.",
		heroTitleLine: "عمل دقيق.",
		heroLead: "بوتات ومواقع وسكربتات وسيرفرات — حسب الوصف، بأسعار واضحة.",
		ctaWhatsapp: "واتساب",
		ctaWork: "الخدمات",
		tickerLabel: "نعمل الآن",
		servicesTitle: "ماذا نصنع",
		servicesLead: "الأسعار نقطة بداية. التفاصيل من الوصف.",
		contactTitle: "تواصل واتساب",
		contactLead: "رقم واحد. محادثة مباشرة. بلا نماذج وبلا حسابات.",
		phoneLabel: "واتساب",
		footerMade: "من صنع شاورما ٢٠٢٣",
		aboutNav: "تعريف",
		aboutOverline: "الممارسة",
		aboutTitle: "استوديو صغير للعمل الرقمي.",
		aboutBody: "شاورما ٢٠٢٣ يبني بوتات ومواقع وسكربتات وبنية تحتية بلا ضجيج. لا تسجيل في هذا الموقع. إن وضح الوصف نبدأ، وإن لم يتضح نتحدث حتى يتضح.",
		verseLabel: "الجمعة ١٠",
		verseText: "فَإِذَا قُضِيَتِ الصَّلَاةُ فَانتَشِرُوا فِي الْأَرْضِ وَابْتَغُوا مِن فَضْلِ اللَّهِ",
		verseTranslation: "فإذا قُضيت الصلاة فانتشروا في الأرض وابتغوا من فضل الله.",
		aboutCredit: "هذا الموقع من صنع شاورما ٢٠٢٣.",
		notFoundTitle: "الصفحة غير موجودة",
		notFoundBody: "هذا المسار ليس جزءاً من الاستوديو.",
		notFoundHome: "العودة للرئيسية",
		waGreeting: "مرحباً شاورما ٢٠٢٣ — أود الحديث عن مشروع.",
		skip: "إلى الأعمال"
	}
};
var LocaleContext = (0, import_react.createContext)(null);
var STORAGE_KEY = "shawarma-locale";
function LocaleProvider({ children }) {
	const [locale, setLocale] = (0, import_react.useState)("en");
	(0, import_react.useEffect)(() => {
		const saved = window.localStorage.getItem(STORAGE_KEY);
		if (saved === "ar" || saved === "en") setLocale(saved);
	}, []);
	(0, import_react.useEffect)(() => {
		const dir = locale === "ar" ? "rtl" : "ltr";
		const lang = locale === "ar" ? "ar" : "en";
		document.documentElement.lang = lang;
		document.documentElement.dir = dir;
		window.localStorage.setItem(STORAGE_KEY, locale);
	}, [locale]);
	const toggle = (0, import_react.useCallback)(() => {
		setLocale((prev) => prev === "en" ? "ar" : "en");
	}, []);
	const value = (0, import_react.useMemo)(() => {
		const dict = copy[locale];
		return {
			locale,
			dir: locale === "ar" ? "rtl" : "ltr",
			t: (key) => dict[key],
			toggle
		};
	}, [locale, toggle]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocaleContext.Provider, {
		value,
		children
	});
}
function useLocale() {
	const ctx = (0, import_react.useContext)(LocaleContext);
	if (!ctx) throw new Error("useLocale must be used within LocaleProvider");
	return ctx;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "bg-transparent text-muted hover:text-foreground",
			link: "bg-transparent text-foreground underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 rounded-md px-4",
			sm: "h-9 rounded-md px-3",
			lg: "h-12 rounded-lg px-6",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function SiteHeader() {
	const { t, toggle } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "text-xs font-medium tracking-[0.22em] text-foreground uppercase",
				children: t("brand")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex items-center gap-1 sm:gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/#work",
						className: "inline-flex h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground",
						children: t("navWork")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/about",
						className: "inline-flex h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground",
						children: t("navAbout")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/#contact",
						className: "hidden h-11 items-center px-2.5 text-sm text-muted transition-colors duration-150 hover:text-foreground sm:inline-flex",
						children: t("navContact")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: toggle,
						"aria-label": t("langAria"),
						className: "ms-1 min-w-11 tracking-wide",
						children: t("langShort")
					})
				]
			})]
		})
	});
}
function SiteFooter() {
	const { t } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl flex-col gap-4 px-4 py-8 pb-24 sm:flex-row sm:items-center sm:justify-between sm:px-6 sm:pb-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("footerMade")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-x-5 gap-y-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/about",
					className: "text-muted transition-colors duration-150 hover:text-foreground",
					children: t("navAbout")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: whatsappHref(t("waGreeting")),
					target: "_blank",
					rel: "noopener noreferrer",
					className: "text-muted transition-colors duration-150 hover:text-foreground",
					children: WHATSAPP_DISPLAY
				})]
			})]
		})
	});
}
function WhatsappFab() {
	const { t } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: whatsappHref(t("waGreeting")),
		target: "_blank",
		rel: "noopener noreferrer",
		"aria-label": t("ctaWhatsapp"),
		className: "fixed end-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-40 grid size-12 place-items-center rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-border)] transition-[transform,opacity] duration-150 ease-out hover:opacity-90 active:scale-[0.96] sm:end-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
			className: "size-5",
			strokeWidth: 1.75
		})
	});
}
function SiteShell({ children }) {
	const { t } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground",
				children: t("skip")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappFab, {})
		]
	});
}
function NotFoundPage() {
	const { t } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-[60dvh] max-w-5xl flex-col justify-center px-4 py-20 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl text-foreground",
				children: t("notFoundTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-muted",
				children: t("notFoundBody")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						children: t("notFoundHome")
					})
				})
			})
		]
	});
}
var styles_default = "/assets/styles-C-3qVmvW.css";
var APP_NAME = "Shawarma 2023";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Shawarma 2023 — digital studio for WhatsApp bots, Telegram bots, websites, scripts, codes, servers, VPS, and domains."
			},
			{
				name: "theme-color",
				content: "#0a0a0b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=IBM+Plex+Sans+Arabic:wght@400;500;600&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&family=Outfit:wght@300;400;500;600&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	notFoundComponent: NotFoundPage,
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		dir: "ltr",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocaleProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$1 = () => import("./routes-CU6NT2Az.mjs");
var Route$1 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./about-CnchEqVS.mjs");
var Route = createFileRoute("/about")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	AboutRoute: Route.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { SERVICES as a, WHATSAPP_DISPLAY as c, useLocale as i, whatsappHref as l, Button as n, SERVICE_IDS as o, cn as r, VERSE_LINES as s, router_exports as t };
