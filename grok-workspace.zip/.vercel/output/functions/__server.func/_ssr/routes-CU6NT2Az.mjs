import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { a as SERVICES, c as WHATSAPP_DISPLAY, i as useLocale, l as whatsappHref, n as Button, o as SERVICE_IDS, r as cn } from "./router-nl0aqhFL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CU6NT2Az.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FloatingShapes() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "shape-stage",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape-mark shape-a" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape-mark shape-b" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape-mark shape-c" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape-mark shape-d" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape-mark shape-e" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape-mark shape-f" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape-mark shape-g" })
		]
	});
}
var shapeClass = {
	square: "rounded-sm",
	circle: "rounded-full",
	diamond: "rotate-45 rounded-sm scale-75",
	hex: "rotate-12 rounded-md",
	rect: "rounded-sm scale-x-75",
	bars: "rounded-sm",
	octagon: "rounded-lg",
	ring: "rounded-full ring-1 ring-border"
};
function ShapeMark({ shape, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid size-11 place-items-center border border-border text-foreground", shapeClass[shape], className),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("grid place-items-center", shape === "diamond" && "-rotate-45"),
			children
		})
	});
}
var VISIBLE = 3;
function ServiceTicker() {
	const { t } = useLocale();
	const [offset, setOffset] = (0, import_react.useState)(0);
	const [stepping, setStepping] = (0, import_react.useState)(false);
	const steppingRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const tick = () => {
			if (document.visibilityState === "hidden") return;
			if (steppingRef.current) return;
			steppingRef.current = true;
			setStepping(true);
		};
		const id = window.setInterval(tick, 3200);
		return () => window.clearInterval(id);
	}, []);
	const handleTransitionEnd = (event) => {
		if (event.propertyName !== "transform") return;
		if (!stepping) return;
		setOffset((value) => (value + 1) % SERVICE_IDS.length);
		setStepping(false);
		steppingRef.current = false;
	};
	const windowIds = [
		0,
		1,
		2,
		3
	].map((slot) => SERVICE_IDS[(offset + slot) % SERVICE_IDS.length]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-label": t("tickerLabel"),
		className: "w-full",
		dir: "ltr",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-5 text-xs font-medium tracking-[0.22em] text-subtle uppercase",
			children: t("tickerLabel")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("ticker-row", stepping && "ticker-step"),
				onTransitionEnd: handleTransitionEnd,
				children: windowIds.map((id, slot) => {
					const service = SERVICES[id];
					const Icon = service.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cn("flex w-1/4 shrink-0 flex-col items-center gap-3 px-2 text-center transition-[opacity,filter] duration-700", (slot === VISIBLE && !stepping || stepping && slot === 0) && "opacity-0 blur-[4px]"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShapeMark, {
							shape: service.shape,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4",
								strokeWidth: 1.6
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-sm leading-snug text-foreground sm:text-base sm:whitespace-nowrap",
							children: service.ticker
						})]
					}, `${id}-${offset}-${slot}`);
				})
			})
		})]
	});
}
function ServiceGrid() {
	const { locale, t } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "work",
		className: "scroll-mt-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-3xl text-foreground sm:text-4xl",
				children: t("servicesTitle")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: t("servicesLead")
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-10 grid grid-cols-1 gap-3 sm:grid-cols-2",
			children: SERVICE_IDS.map((id) => {
				const service = SERVICES[id];
				const Icon = service.icon;
				const copy = service[locale];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "flex h-full gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShapeMark, {
						shape: service.shape,
						className: "shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-4",
							strokeWidth: 1.6
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-sans text-base font-medium tracking-tight text-foreground",
								children: copy.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "shrink-0 text-xs tracking-wide text-subtle",
								children: copy.price
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: copy.blurb
						})]
					})]
				}) }, id);
			})
		})]
	});
}
function ContactBlock() {
	const { t } = useLocale();
	const href = whatsappHref(t("waGreeting"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "scroll-mt-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-card p-6 shadow-[var(--shadow-border)] sm:p-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.22em] text-subtle uppercase",
					children: t("phoneLabel")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 text-3xl text-foreground sm:text-4xl",
					children: t("contactTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-lg text-muted",
					children: t("contactLead")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "mt-8 block font-display text-3xl tracking-tight text-foreground sm:text-5xl",
					dir: "ltr",
					children: WHATSAPP_DISPLAY
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href,
							target: "_blank",
							rel: "noopener noreferrer",
							children: [t("ctaWhatsapp"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
								className: "size-4",
								strokeWidth: 1.75
							})]
						})
					})
				})
			]
		})
	});
}
function Home() {
	const { t } = useLocale();
	const href = whatsappHref(t("waGreeting"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingShapes, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-[calc(100dvh-3.5rem)] max-w-5xl flex-col justify-center gap-12 px-4 py-16 sm:px-6 sm:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "enter-1 text-xs font-medium tracking-[0.22em] text-subtle uppercase",
						children: t("overline")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "enter-2 mt-4 text-4xl leading-[1.08] text-foreground sm:text-6xl",
						children: [t("heroTitle"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block",
							children: t("heroTitleLine")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "enter-3 mt-5 max-w-lg text-base leading-relaxed text-muted sm:text-lg",
						children: t("heroLead")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "enter-4 mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href,
								target: "_blank",
								rel: "noopener noreferrer",
								children: [t("ctaWhatsapp"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									className: "size-4",
									strokeWidth: 1.75
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#work",
								children: t("ctaWork")
							})
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "enter-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTicker, {})
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-5xl flex-col gap-24 px-4 py-16 sm:px-6 sm:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceGrid, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactBlock, {})]
	})] });
}
//#endregion
export { Home as component };
