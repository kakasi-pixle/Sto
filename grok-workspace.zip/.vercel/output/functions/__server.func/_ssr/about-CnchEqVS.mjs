import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useLocale, s as VERSE_LINES } from "./router-nl0aqhFL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-CnchEqVS.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	const { t } = useLocale();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "enter-1 text-xs font-medium tracking-[0.22em] text-subtle uppercase",
				children: t("aboutOverline")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "enter-2 mt-4 max-w-2xl text-4xl leading-[1.1] text-foreground sm:text-5xl",
				children: t("aboutTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "enter-3 mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
				children: t("aboutBody")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "enter-4 mx-auto mt-20 max-w-2xl rounded-2xl bg-card px-6 py-12 text-center shadow-[var(--shadow-border)] sm:px-12 sm:py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "text-xs font-medium tracking-[0.22em] text-subtle uppercase",
						children: t("verseLabel")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
						lang: "ar",
						dir: "rtl",
						className: "font-verse mt-8 text-2xl leading-[2.05] text-foreground sm:text-3xl",
						children: VERSE_LINES.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block",
							children: [
								index === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "﴿"
								}) : null,
								line,
								index === VERSE_LINES.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "﴾"
								}) : null
							]
						}, line))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-8 max-w-md text-sm leading-relaxed text-muted",
						children: t("verseTranslation")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-16 text-sm text-muted",
				children: t("aboutCredit")
			})
		]
	});
}
//#endregion
export { About as component };
